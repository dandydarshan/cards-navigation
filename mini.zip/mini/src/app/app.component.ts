import { Component } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig } from '@angular/material';
import { TextDialogComponent } from './text-dialog/text-dialog.component';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.sass']
})
export class AppComponent {
  defaultText = ' some default text string';
  newText = 'some other text';

  // new text can be equal to old text initially

  constructor(public dialog: MatDialog) { }

  expandDialog(): void {

    const dialogConfig = new MatDialogConfig();
    // dailog configuration
    dialogConfig.minWidth = '1000px';
    dialogConfig.minHeight = '500px';
    dialogConfig.maxWidth = '1050px';
    dialogConfig.maxHeight = '1050px';
    dialogConfig.data = {
      oldDescription: this.defaultText,
      newDescription: this.newText
    };

    const dialogRef = this.dialog.open(TextDialogComponent, dialogConfig);

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.newText = result;
      }
    });
  }
}
