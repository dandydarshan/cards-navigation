import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

@Component({
  selector: 'app-text-dialog',
  templateUrl: './text-dialog.component.html',
  styleUrls: ['./text-dialog.component.scss']
})
export class TextDialogComponent implements OnInit {

  newValue: string;
  oldValue: string;

  constructor(public dialogRef: MatDialogRef<TextDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any) {
    this.newValue = data.newDescription;
    this.oldValue = data.oldDescription;
  }

  ngOnInit() {
  }

  cancel(): void {
    this.dialogRef.close();
  }

}
