import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  isCardImgLoaded = false;

  constructor() { }

  ngOnInit(): void {
    setTimeout(() => {
      this.isCardImgLoaded = true;
    }, 3000);
  }
}
